import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-delivery',
  templateUrl: './list-delivery.component.html',
  styleUrls: ['./list-delivery.component.scss']
})
export class ListDeliveryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
