import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { VendorComponent } from './vendor/vendor.component';
import { AdminComponent } from './admin/admin.component';
import { compileBaseDefFromMetadata } from '@angular/compiler';
import { AddItemComponent } from './add-item/add-item.component';
import { EditItemComponent } from './edit-item/edit-item.component';
import { ListItemComponent } from './list-item/list-item.component';
import { AddStockComponent } from './add-stock/add-stock.component';
import { EditStockComponent } from './edit-stock/edit-stock.component';
import { ListStockComponent } from './list-stock/list-stock.component';
import { AddUserComponent } from './add-user/add-user.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { ListUserComponent } from './list-user/list-user.component';
import { ListSaleComponent } from './list-sale/list-sale.component';
import { ListDeliveryComponent } from './list-delivery/list-delivery.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { ListOrderComponent } from './list-order/list-order.component';
import { ListPaymentComponent } from './list-payment/list-payment.component';
import { OrderDetailComponent } from './order-detail/order-detail.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';


const routes: Routes = [
  {
    path:'',
    component:HomeComponent
  },
  {
    path:'home',
    component:HomeComponent
  },
  {
    path:'vendor',
    component:VendorComponent
  },
  {
    path:'admin',
    component:AdminComponent
  },
  {
    path:'add-item',
    component:AddItemComponent
  },
  {
    path:'edit-item',
    component:EditItemComponent
  },
  {
    path:'list-item',
    component:ListItemComponent
  },
  {
    path:'add-stock',
    component:AddStockComponent
  },
  {
    path:'edit-stock',
    component:EditStockComponent
  },
  {
    path:'list-stock',
    component:ListStockComponent
  },
  {
    path:'add-user',
    component:AddUserComponent
  },
  {
    path:'edit-user',
    component:EditUserComponent
  },
  {
    path:'list-user',
    component:ListUserComponent
  },
  {
    path:'list-sale',
    component:ListSaleComponent
  },
  {
    path:'list-delivery',
    component:ListDeliveryComponent
  },
  {
    path:'my-profile',
    component:MyProfileComponent
  },
  {
    path:'list-order',
    component:ListOrderComponent
  },
  {
    path:'list-payment',
    component:ListPaymentComponent
  },
  {
    path:'order-detail',
    component:OrderDetailComponent
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'registration',
    component:RegistrationComponent
  },
  {
    path:'reset-password',
    component:ResetPasswordComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
