import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-payment',
  templateUrl: './list-payment.component.html',
  styleUrls: ['./list-payment.component.scss']
})
export class ListPaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
