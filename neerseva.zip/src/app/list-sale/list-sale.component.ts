import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-sale',
  templateUrl: './list-sale.component.html',
  styleUrls: ['./list-sale.component.scss']
})
export class ListSaleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
