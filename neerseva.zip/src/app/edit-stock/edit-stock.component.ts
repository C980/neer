import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-stock',
  templateUrl: './edit-stock.component.html',
  styleUrls: ['./edit-stock.component.scss']
})
export class EditStockComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
